package com.fqz.bluetoothterminal.settings

import android.content.Context
import java.nio.charset.Charset

object AppSettings {
    private const val PREFS_NAME = "app_settings"
    private const val KEY_TX_ENCODING = "tx_encoding"
    private const val KEY_RX_ENCODING = "rx_encoding"
    private const val KEY_LINE_ENDING = "tx_line_ending"
    private const val KEY_PARSE_ENABLED = "parse_enabled"
    private const val KEY_AI_ENABLED = "ai_enabled"
    private const val KEY_AI_ENDPOINT = "ai_endpoint"
    private const val KEY_AI_API_KEY = "ai_api_key"
    private const val KEY_AI_MODEL = "ai_model"

    const val LINE_ENDING_NONE = "NONE"
    const val LINE_ENDING_LF = "LF"
    const val LINE_ENDING_CRLF = "CRLF"

    fun getTxCharset(context: Context): Charset {
        val name = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TX_ENCODING, Charsets.UTF_8.name()).orEmpty()
        return runCatching { Charset.forName(name) }.getOrDefault(Charsets.UTF_8)
    }

    fun getRxCharset(context: Context): Charset {
        val name = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_RX_ENCODING, Charsets.UTF_8.name()).orEmpty()
        return runCatching { Charset.forName(name) }.getOrDefault(Charsets.UTF_8)
    }

    fun getLineEnding(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LINE_ENDING, LINE_ENDING_NONE)
            ?: LINE_ENDING_NONE
    }

    fun setTxEncoding(context: Context, charsetName: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TX_ENCODING, charsetName)
            .apply()
    }

    fun setRxEncoding(context: Context, charsetName: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_RX_ENCODING, charsetName)
            .apply()
    }

    fun setLineEnding(context: Context, lineEnding: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LINE_ENDING, lineEnding)
            .apply()
    }

    fun isParseEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PARSE_ENABLED, false)
    }

    fun setParseEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_PARSE_ENABLED, enabled)
            .apply()
    }

    fun isAiEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_AI_ENABLED, false)
    }

    fun setAiEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AI_ENABLED, enabled)
            .apply()
    }

    fun getAiEndpoint(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_AI_ENDPOINT, "")
            .orEmpty()
            .trim()
    }

    fun setAiEndpoint(context: Context, endpoint: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_AI_ENDPOINT, endpoint.trim())
            .apply()
    }

    fun getAiApiKey(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_AI_API_KEY, "")
            .orEmpty()
            .trim()
    }

    fun setAiApiKey(context: Context, apiKey: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_AI_API_KEY, apiKey.trim())
            .apply()
    }

    fun getAiModel(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_AI_MODEL, "")
            .orEmpty()
            .trim()
    }

    fun setAiModel(context: Context, model: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_AI_MODEL, model.trim())
            .apply()
    }
}

